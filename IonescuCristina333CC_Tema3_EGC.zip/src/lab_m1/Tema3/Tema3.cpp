#include "lab_m1/Tema3/Tema3.h"

#include <vector>
#include <string>
#include <iostream>
#include <random>
#include <map>
#include <glm/glm.hpp>
#include <glm/gtc/random.hpp>

using namespace std;
using namespace m1;

Tema3::Tema3()
{
}


Tema3::~Tema3()
{
}


void Tema3::Init()
{
    camera = new implemented::Camera3();
    camera->Set(glm::vec3(0, 12, 20), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
    // camera->distanceToTarget = glm::distance(cameraPoz + glm::vec3(0, 1.5, 0), catPosition);

    projectionMatrix = glm::perspective(RADIANS(180), window->props.aspectRatio, 0.2f, 300.0f);

    Mesh* far_base = new Mesh("far_base");
    far_base->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "far_base.obj");
    meshes[far_base->GetMeshID()] = far_base;

    Mesh* far_glass = new Mesh("far_glass");
    far_glass->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "far_glass.obj");
    meshes[far_glass->GetMeshID()] = far_glass;

    Mesh* far_top = new Mesh("far_top");
    far_top->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "far_top.obj");
    meshes[far_top->GetMeshID()] = far_top;

    Mesh* grass = new Mesh("grass");
    grass->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "grass.obj");
    meshes[grass->GetMeshID()] = grass;

    Mesh* water = new Mesh("water");
    water->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "water.obj");
    meshes[water->GetMeshID()] = water;

    {
        Mesh* boat_base = new Mesh("boat_base");
        boat_base->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "boat-base.obj");
        meshes[boat_base->GetMeshID()] = boat_base;

        Mesh* boat_vela = new Mesh("boat_vela");
        boat_vela->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "boat-vela.obj");
        meshes[boat_vela->GetMeshID()] = boat_vela;

        Mesh* boat_stick = new Mesh("boat_stick");
        boat_stick->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "boat-stick.obj");
        meshes[boat_stick->GetMeshID()] = boat_stick;

        Mesh* boat_flag = new Mesh("boat_flag");
        boat_flag->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far"), "boat-flag.obj");
        meshes[boat_flag->GetMeshID()] = boat_flag;

        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "wood.jpg").c_str(), GL_REPEAT);
        mapTextures["boat_base_texture"] = texture;

        texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "vela.jpg").c_str(), GL_REPEAT);
        mapTextures["boat_vela_texture"] = texture;

        texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "flag.jpg").c_str(), GL_REPEAT);
        mapTextures["boat_flag_texture"] = texture;
    }



    {
        Mesh* mesh = new Mesh("sphere");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "sphere.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "grass3.jpg").c_str(), GL_REPEAT);
        mapTextures["grass_texture"] = texture;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "download.jpg").c_str(), GL_REPEAT);
        mapTextures["glass_texture"] = texture;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "concrete.jpg").c_str(), GL_REPEAT);
        mapTextures["concrete"] = texture;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "moon.jpg").c_str(), GL_REPEAT);
        mapTextures["moon"] = texture;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "far", "water.jpg").c_str(), GL_REPEAT);
        mapTextures["water"] = texture;
    }

    // Create a shader program for drawing face polygon with the color of the normal
    {
        Shader* shader = new Shader("LabShader");
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema3", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema3", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
        shader->CreateAndLink();
        shaders[shader->GetName()] = shader;
    }

    // Light & material properties
    {
        lightPosition = glm::vec3(0, 1, 1);
        materialShininess = 30;
        materialKd = 0.5;
        materialKs = 0.5;
    }
}


void Tema3::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}


void Tema3::Update(float deltaTimeSeconds)
{ 
    glm::ivec2 resolution = window->GetResolution();

    glViewport(0, 0, resolution.x, resolution.y);

    glm::mat4 modelMatrix = glm::mat4(1);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0, 0));
    RenderSimpleMesh(meshes["far_base"], shaders["LabShader"], modelMatrix, mapTextures["concrete"]);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.02f, 0));
    RenderSimpleMesh(meshes["far_glass"], shaders["LabShader"], modelMatrix, mapTextures["glass_texture"]);
    RenderSimpleMesh(meshes["far_top"], shaders["LabShader"], modelMatrix, mapTextures["concrete"]);

    modelMatrix = glm::mat4(1);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0, 0));
    RenderSimpleMesh(meshes["grass"], shaders["LabShader"], modelMatrix, mapTextures["grass_texture"]);


    {
        // the moon
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(-13, 15, -13));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(4));
        RenderSimpleMesh(meshes["sphere"], shaders["LabShader"], modelMatrix, mapTextures["moon"]);
    }

    {
        // sea
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(150));
        RenderSimpleMesh(meshes["water"], shaders["LabShader"], modelMatrix, mapTextures["water"]);
    }

    {
        // boat 1

        angularStep1 += deltaTimeSeconds * 50;
        angularStep2 += deltaTimeSeconds * 30;
        angularStep3 += deltaTimeSeconds * 40;
        angularStep4 += deltaTimeSeconds * 37;
        glm::vec3 rotationCenter = glm::vec3(0, -0.1, 0);

        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, -rotationCenter);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.9));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(angularStep1), glm::vec3(0, 1, 0));
        modelMatrix = glm::translate(modelMatrix, rotationCenter);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(6, -0.1, 0));

        RenderSimpleMesh(meshes["boat_base"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_vela"], shaders["LabShader"], modelMatrix, mapTextures["boat_vela_texture"]);
        RenderSimpleMesh(meshes["boat_stick"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_flag"], shaders["LabShader"], modelMatrix, mapTextures["boat_flag_texture"]);

        // boat 2
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, -rotationCenter);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.9));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(-angularStep2), glm::vec3(0, 1, 0));
        modelMatrix = glm::translate(modelMatrix, rotationCenter);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(-10, -0.1, 0));

        RenderSimpleMesh(meshes["boat_base"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_vela"], shaders["LabShader"], modelMatrix, mapTextures["boat_vela_texture"]);
        RenderSimpleMesh(meshes["boat_stick"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_flag"], shaders["LabShader"], modelMatrix, mapTextures["boat_flag_texture"]);

        // boat 3
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, -rotationCenter);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.9));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(angularStep3), glm::vec3(0, 1, 0));
        modelMatrix = glm::translate(modelMatrix, rotationCenter);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(12, -0.1, 0));

        RenderSimpleMesh(meshes["boat_base"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_vela"], shaders["LabShader"], modelMatrix, mapTextures["boat_vela_texture"]);
        RenderSimpleMesh(meshes["boat_stick"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_flag"], shaders["LabShader"], modelMatrix, mapTextures["boat_flag_texture"]);

        // boat 4
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, -rotationCenter);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.9));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(-angularStep4), glm::vec3(0, 1, 0));
        modelMatrix = glm::translate(modelMatrix, rotationCenter);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(-14, -0.1, 0));

        RenderSimpleMesh(meshes["boat_base"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_vela"], shaders["LabShader"], modelMatrix, mapTextures["boat_vela_texture"]);
        RenderSimpleMesh(meshes["boat_stick"], shaders["LabShader"], modelMatrix, mapTextures["boat_base_texture"]);
        RenderSimpleMesh(meshes["boat_flag"], shaders["LabShader"], modelMatrix, mapTextures["boat_flag_texture"]);
    }

}

void Tema3::FrameEnd()
{
    //DrawCoordinateSystem();
}

void Tema3::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, Texture2D* texture1, Texture2D* texture2)
{
    if (!mesh || !shader || !shader->GetProgramID())
        return;

    glUseProgram(shader->program);

    GLint light_position = glGetUniformLocation(shader->program, "light_position");
    glUniform3fv(light_position, 1, glm::value_ptr(lightPosition));

    glm::vec3 eyePosition = GetSceneCamera()->m_transform->GetWorldPosition();

    GLint eye_position = glGetUniformLocation(shader->program, "eye_position");
    glUniform3fv(eye_position, 1, glm::value_ptr(eyePosition));

    GLint shininess_position = glGetUniformLocation(shader->program, "material_shininess");
    glUniform1i(shininess_position, materialShininess);

    GLint kd_position = glGetUniformLocation(shader->program, "material_kd");
    glUniform1f(kd_position, materialKd);

    GLint ks_position = glGetUniformLocation(shader->program, "material_ks");
    glUniform1f(ks_position, materialKs);

    GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
    glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    glm::mat4 viewMatrix = camera->GetViewMatrix();
    int loc_view_matrix = glGetUniformLocation(shader->program, "View");
    glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

    glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
    int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
    glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

    if (texture1)
    {
        glActiveTexture(GL_TEXTURE0);

        glBindTexture(GL_TEXTURE_2D, texture1->GetTextureID());

        glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);
    }

    glUniform1f(glGetUniformLocation(shader->program, "time"), Engine::GetElapsedTime());

    globe = 0;

    if (!strncmp(mesh->GetMeshID(), "water", 6)) {
        globe = 1;
    }

    glUniform1i(glGetUniformLocation(shader->program, "globe"), globe);

    glBindVertexArray(mesh->GetBuffers()->m_VAO);
    glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_INT, 0);
}

void Tema3::OnInputUpdate(float deltaTime, int mods)
{
    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float cameraSpeed = 5.0f;

        if (window->KeyHold(GLFW_KEY_W)) {
            camera->TranslateForward(deltaTime * cameraSpeed);

        }

        if (window->KeyHold(GLFW_KEY_A)) {
            camera->TranslateRight(deltaTime * cameraSpeed * (-1));

        }

        if (window->KeyHold(GLFW_KEY_S)) {
            camera->TranslateForward(deltaTime * cameraSpeed * (-1));

        }

        if (window->KeyHold(GLFW_KEY_D)) {
            camera->TranslateRight(deltaTime * cameraSpeed);

        }

        if (window->KeyHold(GLFW_KEY_Q)) {
            camera->TranslateUpward(deltaTime * cameraSpeed * (-1));

        }

        if (window->KeyHold(GLFW_KEY_E)) {
            camera->TranslateUpward(deltaTime * cameraSpeed);

        }
    }

}


void Tema3::OnKeyPress(int key, int mods)
{

}


void Tema3::OnKeyRelease(int key, int mods)
{

}


void Tema3::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float sensivityOX = 0.001f;
        float sensivityOY = 0.001f;

        if (window->GetSpecialKeyState() == 0) {
            renderCameraTarget = false;

            camera->RotateFirstPerson_OX(-sensivityOX * deltaY);
            camera->RotateFirstPerson_OY(-sensivityOY * deltaX);

        }

        if (window->GetSpecialKeyState() & GLFW_MOD_CONTROL) {
            renderCameraTarget = true;

            camera->RotateFirstPerson_OX(-sensivityOX * deltaY);
            camera->RotateFirstPerson_OY(-sensivityOY * deltaX);
        }
    }

}

void Tema3::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{

}


void Tema3::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{

}


void Tema3::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema3::OnWindowResize(int width, int height)
{
}