#pragma once

#include <string>

#include "core/gpu/mesh.h"
#include "utils/glm_utils.h"


namespace object3D_T3
{

    Mesh* CreateWall(const std::string& name, glm::vec3 middleCorner, float length, glm::vec3 color, bool fill = false);
    Mesh* CreateFloor(const std::string& name, glm::vec3 middleCorner, float length, glm::vec3 color, bool fill = false);
    Mesh* CreateBuilding(const std::string& name, glm::vec3 middleCorner, float length, glm::vec3 color, float factorHeight, float minFactor, bool fill = false);

}
