#pragma once

/*
 *  See: https://www.glfw.org/docs/latest/build_guide.html#build_include
 */

#ifndef GLFW_INCLUDE_NONE
#   define GLFW_INCLUDE_NONE
#endif

#include "GLFW/glfw3.h"
