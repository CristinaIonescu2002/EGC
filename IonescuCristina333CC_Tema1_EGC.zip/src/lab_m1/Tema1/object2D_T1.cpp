﻿#include "object2D_T1.h"

#include <vector>

#include "core/engine.h"
#include "utils/gl_utils.h"


Mesh* object2D_T1::CreateSquare(
    const std::string &name,
    glm::vec3 leftBottomCorner,
    float length,
    glm::vec3 color,
    bool fill)
{
    glm::vec3 corner = leftBottomCorner;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(corner, color),
        VertexFormat(corner + glm::vec3(length, 0, 0), color),
        VertexFormat(corner + glm::vec3(length, length, 0), color),
        VertexFormat(corner + glm::vec3(0, length, 0), color)
    };

    Mesh* square = new Mesh(name);
    std::vector<unsigned int> indices = { 0, 1, 2, 3 };

    if (!fill) {
        square->SetDrawMode(GL_LINE_LOOP);
    } else {
        indices.push_back(0);
        indices.push_back(2);
    }

    square->InitFromData(vertices, indices);

    return square;
}

Mesh* object2D_T1::CreateRectangle(
    const std::string& name,
    glm::vec3 leftBottomCorner,
    float lungime,
    float latime,
    glm::vec3 color,
    bool fill)
{
    glm::vec3 corner = leftBottomCorner;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(corner, color),
        VertexFormat(corner + glm::vec3(latime, 0, 0), color),
        VertexFormat(corner + glm::vec3(latime, lungime, 0), color),
        VertexFormat(corner + glm::vec3(0, lungime, 0), color)
    };

    Mesh* rectangle = new Mesh(name);
    std::vector<unsigned int> indices =
    {
        0, 1, 2,
        2, 3, 0,
    };

    rectangle->InitFromData(vertices, indices);

    return rectangle;
}

Mesh* object2D_T1::CreateStar(
    const std::string& name,
    glm::vec3 leftBottomCorner,
    float length,
    glm::vec3 color, 
    float positionZ)
{
    const int sides = 5;
    const float pi = glm::pi<float>();

    std::vector<VertexFormat> vertices;
    glm::vec3 center(length / 2, length / 2, positionZ);

    vertices.push_back(VertexFormat(center, color));

    for (int i = 0; i <= sides; ++i) {
        float angle = 2.0f * pi * i / sides + 180;
        float x = center.x + length / 2 * cos(angle);
        float y = center.y + length / 2 * sin(angle);
        vertices.push_back(VertexFormat(glm::vec3(x, y, positionZ), color));
    }

    std::vector<unsigned int> indices =
    {
        0, 2, 5,
        0, 3, 5,
        0, 1, 3,
        0, 1, 4,
        0, 4, 2
    };

    Mesh* star = new Mesh(name);
    star->SetDrawMode(GL_TRIANGLES);
    star->InitFromData(vertices, indices);
    //star->SetDrawMode(GL_LINE_LOOP);

    return star;
}

Mesh* object2D_T1::CreateWeapon(
    const std::string& name,
    glm::vec3 leftBottomCorner,
    float length,
    glm::vec3 color,
    float positionZ)
{
    glm::vec3 corner = leftBottomCorner;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(corner + glm::vec3(length / 2, 0, positionZ), color),
        VertexFormat(corner + glm::vec3(0, length, positionZ), color),
        VertexFormat(corner + glm::vec3(length / 2, length * 2, positionZ), color),
        VertexFormat(corner + glm::vec3(length, length, positionZ), color),

        VertexFormat(corner + glm::vec3(length / 2, length - length / 5, positionZ), color),
        VertexFormat(corner + glm::vec3(length / 2, length + length / 5, positionZ), color),
        VertexFormat(corner + glm::vec3(length / 2 + length, length + length / 5, positionZ), color),
        VertexFormat(corner + glm::vec3(length / 2 + length, length - length / 5, positionZ), color)
    };

    Mesh* romb = new Mesh(name);
    std::vector<unsigned int> indices =
    {
        3, 0, 1,
        1, 2, 3,
        4, 5, 6,
        6, 7, 4
    };

    romb->InitFromData(vertices, indices);

    return romb;
}

Mesh* object2D_T1::CreateLife(
    const std::string& name,
    glm::vec3 leftBottomCorner,
    float length,
    glm::vec3 color)
{
    glm::vec3 corner = leftBottomCorner;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(corner + glm::vec3(length / 8 * 4, 0, 0), color),
        VertexFormat(corner + glm::vec3(0, length / 8 * 4, 0), color),
        VertexFormat(corner + glm::vec3(0, length / 8 * 6, 0), color),
        VertexFormat(corner + glm::vec3(length / 8, length, 0), color),

        VertexFormat(corner + glm::vec3(length / 8 * 3, length, 0), color),
        VertexFormat(corner + glm::vec3(length / 8 * 4, length / 8 * 6, 0), color),
        VertexFormat(corner + glm::vec3(length / 8 * 5, length, 0), color),
        VertexFormat(corner + glm::vec3(length / 8 * 7, length, 0), color),

        VertexFormat(corner + glm::vec3(length, length / 8 * 6, 0), color),
        VertexFormat(corner + glm::vec3(length, length / 8 * 4, 0), color)

    };

    Mesh* life = new Mesh(name);
    std::vector<unsigned int> indices =
    {
        9, 0, 1,

        1, 2, 8,
        9, 1, 8,

        2, 4, 5,
        2, 3, 4,

        5, 6, 8,
        6, 7, 8
    };

    life->InitFromData(vertices, indices);

    return life;
}

Mesh* object2D_T1::CreateEnemy(
    const std::string& name,
    glm::vec3 leftBottomCorner,
    float length,
    glm::vec3 color1, 
    glm::vec3 color2)
{
    const int sides = 6;
    const float pi = glm::pi<float>();

    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;
    glm::vec3 center(length, length, 0);

    vertices.push_back(VertexFormat(center, color1));

    for (int i = 0; i < sides; ++i) {
        float angle = 2.0f * pi * i / sides;
        float x = center.x + length * cos(angle);
        float y = center.y + length * sin(angle);
        vertices.push_back(VertexFormat(glm::vec3(x, y, 0.5), color1));
    }

    for (int i = 1; i < sides; i++) {
        indices.push_back(0);
        indices.push_back(i);
        indices.push_back(i + 1);
    }
    indices.push_back(0);
    indices.push_back(sides);
    indices.push_back(1);

    float new_length = length - length * 30 / 100;
    std::vector<VertexFormat> vertices2;
    std::vector<unsigned int> indices2;
    glm::vec3 center2(length, length, 1);

    vertices.push_back(VertexFormat(center2, color2));

    for (int i = 0; i < sides; ++i) {
        float angle = 2.0f * pi * i / sides;
        float x = center2.x + new_length * cos(angle);
        float y = center2.y + new_length * sin(angle);
        vertices.push_back(VertexFormat(glm::vec3(x, y, 0.7), color2));
    }

    for (int i = 1; i < sides; ++i) {
        indices.push_back(7);
        indices.push_back(i + sides + 1);
        indices.push_back(i + sides + 2);
    }
    
    indices.push_back(8);
    indices.push_back(13);
    indices.push_back(7);

    Mesh* hexagon = new Mesh(name);
    hexagon->SetDrawMode(GL_TRIANGLES);
    hexagon->InitFromData(vertices, indices);

    return hexagon;
}