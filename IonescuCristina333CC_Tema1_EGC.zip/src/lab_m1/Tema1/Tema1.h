#pragma once

#include "components/simple_scene.h"


namespace m1
{
    class Tema1 : public gfxc::SimpleScene
    {
     public:
         Tema1();
        ~Tema1();

        void Init() override;

        struct Enemy {
            float positionX;
            float positionY;

            float scaleX = 1;
            float scaleY = 1;

            int hpHears;

            glm::vec3 color;
            std::string name;

            bool erase;
        };
        std::vector<Enemy> enemies;

        struct PointsToCollect {
            float positionX;
            float positionY;
        };
        std::vector<PointsToCollect> pointsToCollect;

        struct WeaponsInAction {
            float positionX;
            float positionY;

            float scaleX = 1;
            float scaleY = 1;

            std::string nameWeapon;
            glm::vec3 color;

            float duration = 4.0f;
            float timer;

            bool erase;

        };
        std::vector<WeaponsInAction> weaponsInAction;



        struct ShootingStars {
            float positionX;
            float positionY;

            float translateX;
            int radians;

            float scaleX = 1;
            float scaleY = 1;

            glm::vec3 color;
            
            bool erase = false;
        };
        std::vector<ShootingStars> shootingStars;

        struct WeaponInMove {
            float positionX;
            float positionY;

            std::string nameWeapon;
            glm::vec3 color;

        };
        WeaponInMove weaponInMove;

        struct AttackPlace {
            float positionX;
            float positionY;

            bool taken = false;

        };
        AttackPlace AttackPlaceMatrix[3][3];

        struct DefaultColorEnemies {
            std::string enemyName;
            glm::vec3 color;

        };
        std::vector<DefaultColorEnemies> defaultColorEnemies;

     private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;

     protected:
        glm::mat3 modelMatrix;

        int pointsNumber = 3;

        bool weaponInMov = false;

        float durationEnemy = 4.3f;
        float timerEnemy;

        float durationPoints = 5.8f;
        float timerPoints;

        float durationShootingStars = 2.3f;

        bool isDragging = false;
        bool gameOver = false;
        int livesLeft = 3;

        int scaling = 0.9;

        float squareSide_weapon_place = 130;

        int starPointsSize = 100;
        int shootingStarSize = 95;
        int weaponSize = 60;
        float squareSide = 130;

        int weaponSizeForColision = 60 - 20;
        int enemyRadius = 50;
        int enemyTypes = 12;

        //enemies
        int enemyHP_hearts = 3;
        int speed_enemie = 74;
        int rotation_enemie = -30;

        float startPositionX = 1200;
        float startPositionY_1 = squareSide_weapon_place / 4;
        float startPositionY_2 = startPositionY_1 + 20 + squareSide_weapon_place;
        float startPositionY_3 = startPositionY_2 + 20 + squareSide_weapon_place;

        std::vector<float> optionsPositionEnemyX = { startPositionY_1, startPositionY_2, startPositionY_3};

        // weapon placement
        float weaponPlaceX_1 = 60;
        float weaponPlaceX_2 = weaponPlaceX_1 * 2 + squareSide_weapon_place;
        float weaponPlaceX_3 = weaponPlaceX_1 * 3 + squareSide_weapon_place * 2;
        float weaponPlaceX_4 = weaponPlaceX_1 * 4 + squareSide_weapon_place * 3;

        float weaponPlaceY = 700 - squareSide_weapon_place;

        float weaponZ = 0.3;

        // attack place
        float row_PlaceX_1 = 100;
        float row_PlaceX_2 = row_PlaceX_1 + 20 + squareSide_weapon_place;
        float row_PlaceX_3 = row_PlaceX_1 + 40  + squareSide_weapon_place * 2;

        float first_rowY = 20;
        float second_rowY = first_rowY * 2 + squareSide_weapon_place;
        float third_rowY = first_rowY * 3 + squareSide_weapon_place * 2;

        // weapons
        float yellow_weaponX = weaponPlaceX_1 + squareSide_weapon_place / 2 - 45;
        float corai_weaponX = squareSide_weapon_place * 2 + squareSide_weapon_place / 2 - 55;
        float purple_weaponX = weaponPlaceX_1 + squareSide_weapon_place * 3 + squareSide_weapon_place / 2 - 55;
        float blue_weaponX = weaponPlaceX_1 * 2 + squareSide_weapon_place * 4 + squareSide_weapon_place / 2 - 55;

        float weaponY = weaponPlaceY + 5;

        // weapon star points
        float starPointsYellowX_1 = 60;
        float offset = 35;
        float speed_star = 333;
        float rotation_star = 170;

        float starPointsCoraiX_1 = starPointsYellowX_1 * 2 + squareSide_weapon_place;
        float starPointsPurpleX_1 = starPointsYellowX_1 * 3 + squareSide_weapon_place * 2;
        float starPointsBlueX_1 = starPointsYellowX_1 * 4 + squareSide_weapon_place * 3;

        float starPointsWeaponY = weaponPlaceY - 40;

        float shootingStars_z = 0.6;

        // life hearts
        float heartX = 250 + squareSide_weapon_place * 4 + 50;
        float offsetHeartsX = 80;

        float heartsY = 700 - squareSide_weapon_place / 2;

        float lifeSize = 60;

        // points
        float pointsY = 700 - squareSide_weapon_place / 2 - 40;
        float pointsX = 250 + squareSide_weapon_place * 4 + 50;

        float offsetPoints_X = 35;
        int ct = false;

        // cost weapons
        int yellow_weapon = 1;
        int corai_weapon = 2;
        int purple_weapon = 2;
        int blue_weapon = 3;

        float constStarSize = 35;

        // rectangle bar

        float sizeRectangle_length = 40 + squareSide_weapon_place * 3;
        float sizeRectangle_height = 60;
    };
}
