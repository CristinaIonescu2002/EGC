#include "object3D_T2.h"

#include <vector>

#include "core/engine.h"
#include "utils/gl_utils.h"


Mesh* object3D_T2::CreateWall(
    const std::string& name,
    glm::vec3 centerDot,
    float length,
    glm::vec3 color,
    bool fill)
{
    glm::vec3 center = centerDot;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(glm::vec3(-length * 13, -length, length), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(length * 13, -length, length), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(-length * 13, length, length), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(length * 13, length, length), glm::vec3(0, 0, 1), color),

        VertexFormat(glm::vec3(-length * 13, -length, -length), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(length * 13, -length, -length), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(-length * 13, length, -length), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(length * 13, length, -length), glm::vec3(0, 0, 1), color)
    };

    Mesh* wall = new Mesh(name);

    std::vector<unsigned int> indices =
    {
        0, 1, 2,
        1, 3, 2,
        2, 3, 7,
        2, 7, 6,
        1, 7, 3,
        1, 5, 7,
        6, 7, 4,
        7, 5, 4,
        0, 4, 1,
        1, 4, 5,
        2, 6, 4,
        0, 2, 4
    };

    wall->InitFromData(vertices, indices);

    return wall;
}

Mesh* object3D_T2::CreateFloor(
    const std::string& name,
    glm::vec3 centerDot,
    float length,
    glm::vec3 color,
    bool fill)
{
    glm::vec3 center = centerDot;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(center + glm::vec3(-length, 0, length), glm::vec3(0, 0, 1), color),
        VertexFormat(center + glm::vec3(-length,0,  -length), glm::vec3(0, 0, 1), color),
        VertexFormat(center + glm::vec3(length,0,  -length), glm::vec3(0, 0, 1), color),
        VertexFormat(center + glm::vec3(length,0,  length), glm::vec3(0, 0, 1), color)
    };

    Mesh* floor = new Mesh(name);
    std::vector<unsigned int> indices =
    {
        0, 1, 2,
        2, 3, 0,
    };

    floor->InitFromData(vertices, indices);

    return floor;
}


Mesh* object3D_T2::CreateBuilding(
    const std::string& name,
    glm::vec3 centerDot,
    float lengthX,
    glm::vec3 color,
    float lengthZ,
    float height,
    bool fill)
{
    glm::vec3 center = centerDot;


    std::vector<VertexFormat> vertices =
    {
        VertexFormat(glm::vec3(-lengthX, 0, lengthZ), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(lengthX, 0, lengthZ), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(-lengthX, height, lengthZ), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(lengthX, height, lengthZ), glm::vec3(0, 0, 1), color),

        VertexFormat(glm::vec3(-lengthX, 0, -lengthZ), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(lengthX, 0, -lengthZ), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(-lengthX, height, -lengthZ), glm::vec3(0, 0, 1), color),
        VertexFormat(glm::vec3(lengthX, height, -lengthZ), glm::vec3(0, 0, 1), color)
    };

    Mesh* wall = new Mesh(name);

    std::vector<unsigned int> indices =
    {
        0, 1, 2,
        1, 3, 2,
        2, 3, 7,
        2, 7, 6,
        1, 7, 3,
        1, 5, 7,
        6, 7, 4,
        7, 5, 4,
        0, 4, 1,
        1, 4, 5,
        2, 6, 4,
        0, 2, 4
    };

    wall->InitFromData(vertices, indices);

    return wall;
}
