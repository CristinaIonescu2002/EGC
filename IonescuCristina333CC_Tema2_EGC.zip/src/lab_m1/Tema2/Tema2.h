﻿#pragma once


#include <string>
#include <unordered_map>

#include "components/simple_scene.h"
#include "lab_m1/Tema2/Tema2_camera.h"
#include "lab_m1/Tema2/object3D_T2.h"
#include "components/transform.h"


namespace m1
{
    class Tema2 : public gfxc::SimpleScene
    {
    public:
        struct ViewportArea
        {
            ViewportArea() : x(0), y(0), width(1), height(1) {}
            ViewportArea(int x, int y, int width, int height)
                : x(x), y(y), width(width), height(height) {}
            int x;
            int y;
            int width;
            int height;
        };
        ViewportArea miniViewportArea;

        Tema2();
        ~Tema2();

        struct BuildingsLimits {
            float X;
            float Z;

            float minX;
            float maxX;

            float minZ;
            float maxZ;

            float limX;
            float limZ;
        };
        std::vector<BuildingsLimits> limits;

        struct AttackProjectile {
            float posX;
            float posZ;

            float directionX = 0;
            float directionZ = 0;

            bool isMooving = true;

            float durationPoints;       // manage disappearing - 5s
            float timerPoints;

            float rotate_delta;
            int rotate_press_num;

        };
        std::vector<AttackProjectile> attackProjectile;

        void Init() override;

    private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix) override;
        void Tema2::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, Texture2D* texture1, int HP);

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;

        void Tema2::ExecuteCurrentState(int i);
        void Tema2::RenderScene(float deltaTimeSeconds);
        bool Tema2::canPlaceObject(float randomX, float randomZ);

        glm::vec3 lightPosition;
        unsigned int materialShininess;
        float materialKd;
        float materialKs;

    protected:
        bool gameOver;

        // for game
        float durationPoints = 120.0f;
        float timerPoints;

        // for main projactile
        float durationPointsProjectile = 1.0f;
        float timerPointsProjectile = 0.0f;
        bool newProjectile = false;
        float speedProjectile = 3.0f;

        float durationPointsEnemies = 2.0f;

        implemented::Camera2* camera;
        implemented::Camera2* camera2;
        glm::mat4 projectionMatrix;
        bool renderCameraTarget;

        float fov;
        float aspect;
        float zNear;
        float zFar;
        float left_p;
        float right_p;
        float bottom_p;
        float top_p;

        int hits = 0;
        int score = 0;
        bool showedScore = false;


        // wall 
        float lengthFactor = 13;

        // main tank pos 0, 0.59, 15
        float cameraX = 0;
        float cameraY = 0.59; 
        float cameraZ = 15;
        float rotate = -90.0f;

        float translateX = 0;
        float translateY = 0;
        float translateZ = 0;

        float roateTutela = -90.0f;

        //border limits
        float minX = -21;
        float maxX = 21;
        float minZ = -21;
        float maxZ = 21;

        //tank collision
        float tankColisionX = 2.9;
        float tankColisionZ = 1.9;

        // tank collision with projectile
        float tankColisionProjectileX = 2;
        float tankColisionProjectileZ = 2;

        glm::vec3 catPosition = glm::vec3(0.0f, 0.59f, 15.0f);
        glm::vec3 firstPos = glm::vec3(0.0f, 0.59f, 15.0f);
        float translate_delta = 0.1f;
        float rotate_delta = 0.03f;
        int translate_press_num = 0;
        int rotate_press_num = 0;
        float catAngle = 1;

        glm::vec3 cameraPoz = catPosition;
        implemented::Camera2* oldCamera = new implemented::Camera2();
        bool da = false;

        // textures 
        std::unordered_map<std::string, Texture2D*> mapTextures;
        GLuint randomTextureID;
        GLboolean mixTextures;
    };
}   // namespace m1