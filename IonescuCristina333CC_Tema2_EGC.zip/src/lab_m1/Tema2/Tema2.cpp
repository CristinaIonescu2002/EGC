#include "lab_m1/Tema2/Tema2.h"

#include <vector>
#include <string>
#include <iostream>
#include <random>
#include <map>
#include <glm/glm.hpp>
#include <glm/gtc/random.hpp>

using namespace std;
using namespace m1;

int generateRandomNumber() {
    return glm::linearRand(-21, 21);
}

int GetRandomNumberInRange(const int minInclusive, const int maxInclusive)
{
    static std::random_device randomDevice;
    static std::default_random_engine randomEngine(randomDevice());

    std::uniform_int_distribution<int> uniformDist(minInclusive, maxInclusive);

    return uniformDist(randomEngine);
}

enum class MovementState
{
    GoingForward,
    GoingBackward,
    InPlaceRotationLeft,
    InPlaceRotationRight
};

struct Enemies {
    glm::vec3 catPosition;
    glm::vec3 oldCatPosition;
    float translate_delta;
    float rotate_delta;
    int translate_press_num;
    int rotate_press_num;
    float rotation = 0.0f;
    bool W;
    bool S;
    MovementState state;
    float durationPoints = 4.0f;
    float timerPoints;
    int hp;
};
std::vector<Enemies> enemies;

MovementState GetNextMovementState(const MovementState currentState)
{
    int randomChange = GetRandomNumberInRange(0, 1);
    MovementState nextState = currentState;

    switch (currentState)
    {
    case MovementState::GoingForward:
    case MovementState::GoingBackward:
        nextState = (randomChange == 1)
            ? MovementState::InPlaceRotationLeft
            : MovementState::InPlaceRotationRight;
        break;

    case MovementState::InPlaceRotationLeft:
    case MovementState::InPlaceRotationRight:
        nextState = (randomChange == 1)
            ? MovementState::GoingForward
            : MovementState::GoingBackward;
        break;

    default:
        break;
    }

    return nextState;
}

std::string GetMovementStateName(const MovementState state)
{
    static const std::map<MovementState, std::string> kStateNames
    {
        { MovementState::GoingForward, "GoingForward" },
        { MovementState::GoingBackward, "GoingBackward" },
        { MovementState::InPlaceRotationLeft, "InPlaceRotationLeft" },
        { MovementState::InPlaceRotationRight, "InPlaceRotationRight" },
    };

    std::string s = "";

    auto it = kStateNames.find(state);
    if (it != kStateNames.end())
    {
        s = kStateNames.at(state);
    }

    return s;
}

bool Tema2::canPlaceObject(float randomX, float randomZ)
{
    bool ok = false;

    if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
        ok = true;
    }

    for (int j = 0; j < enemies.size(); j++) {
        if (abs(enemies[j].catPosition.x - randomX) <= tankColisionX + 1
            && abs(enemies[j].catPosition.z - randomZ) <= tankColisionZ + 1) {
            return false;
        }
    }

    for (int j = 0; j < limits.size(); j++) {
        if ((abs(randomX - limits[j].maxX) <= limits[j].limX || abs(randomX - limits[j].minX) <= limits[j].limX)
            && (abs(randomZ - limits[j].maxZ) <= limits[j].limZ || abs(randomZ - limits[j].minZ) <= limits[j].limZ)) {
            return false;
        }
    }
}

Tema2::Tema2()
{
}


Tema2::~Tema2()
{
}


void Tema2::Init()
{
    gameOver = false;
    timerPoints = durationPoints;

    camera = new implemented::Camera2();
    camera->Set(cameraPoz + glm::vec3(0, 1.5, 1.5), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
    camera->distanceToTarget = glm::distance(cameraPoz + glm::vec3(0, 1.5, 0), catPosition);

    projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);
    fov = RADIANS(110);
    aspect = window->props.aspectRatio;
    zNear = 0.1f;
    zFar = 200.0f;

    {
        // the main floor

        glm::vec3 corner1 = glm::vec3(0, 0, 0);
        Mesh* floor = object3D_T2::CreateFloor("floor", corner1, 30, glm::vec3(0.1f, 0.5f, 0.1f));
        meshes[floor->GetMeshID()] = floor;
    }

    {
        // building management

        // building1 -> blue
        glm::vec3 corner1 = glm::vec3(0, 0, 0);
        Mesh* build1 = object3D_T2::CreateBuilding("build1", corner1, 1, glm::vec3(0, 0, 1), 1, 6);
        meshes[build1->GetMeshID()] = build1;

        Mesh* build2 = object3D_T2::CreateBuilding("build2", corner1, 3, glm::vec3(0, 0, 1), 2, 6);
        meshes[build2->GetMeshID()] = build2;

        Mesh* build3 = object3D_T2::CreateBuilding("build3", corner1, 2, glm::vec3(0, 0, 1), 4, 8);
        meshes[build3->GetMeshID()] = build3;

        Mesh* build4 = object3D_T2::CreateBuilding("build4", corner1, 2, glm::vec3(0, 0, 1), 2, 5);
        meshes[build4->GetMeshID()] = build4;

        Mesh* build5 = object3D_T2::CreateBuilding("build5", corner1, 2, glm::vec3(0, 0, 1), 5, 7);
        meshes[build5->GetMeshID()] = build5;

        Mesh* build6 = object3D_T2::CreateBuilding("build6", corner1, 2, glm::vec3(0, 0, 1), 3, 4);
        meshes[build6->GetMeshID()] = build6;
        
        bool ok = false;
        float randomX, randomZ;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX-1, randomX+1, randomZ-1, randomZ+1, 1.3, 1.3 });

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX-3, randomX+3, randomZ-2, randomZ+2, 2, 1.5 });

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX - 2, randomX + 2, randomZ - 2, randomZ + 2, 2, 2});

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX - 2, randomX +2, randomZ - 2, randomZ + 2, 2, 2});

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX - 2 , randomX + 2, randomZ - 2, randomZ + 2, 2, 2});

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX - 2, randomX + 2, randomZ - 2, randomZ + 2, 2, 2});

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX - 2, randomX + 2, randomZ - 2, randomZ + 2, 2, 2});

        ok = false;
        while (ok == false) {
            randomX = generateRandomNumber();
            randomZ = generateRandomNumber();
            if (abs(randomX - firstPos.x) > tankColisionX + 2 && abs(randomZ - firstPos.z) > tankColisionZ + 2) {
                ok = true;
            }
        }
        limits.push_back({ randomX, randomZ, randomX - 2, randomX + 2, randomZ - 2, randomZ + 2, 2, 2});
    }

    {
        // walls
        glm::vec3 corner1 = glm::vec3(0, 0, 0);
        Mesh* wall = object3D_T2::CreateWall("wall", corner1, 2, glm::vec3(0.2f, 0.2f, 0.2f));
        meshes[wall->GetMeshID()] = wall;
    }

    {
        // tank - main

        // body
        Mesh* tank_body_main = new Mesh("tank_base_main");
        tank_body_main->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-body-main.obj");
        meshes[tank_body_main->GetMeshID()] = tank_body_main;

        // tracks
        Mesh* tank_tracks_main = new Mesh("tank_tracks_main");
        tank_tracks_main->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-tracks-main.obj");
        meshes[tank_tracks_main->GetMeshID()] = tank_tracks_main;

        // top big part
        Mesh* tank_top_big_main = new Mesh("tank_top_big_main");
        tank_top_big_main->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-top-bigPart-main.obj");
        meshes[tank_top_big_main->GetMeshID()] = tank_top_big_main;

        // top small part
        Mesh* tank_top_small_main = new Mesh("tank_top_small_main");
        tank_top_small_main->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-top-smallPart-main.obj");
        meshes[tank_top_small_main->GetMeshID()] = tank_top_small_main;

        //// tank enemy

        // body
        Mesh* tank_body_enemy = new Mesh("tank_base_enemy");
        tank_body_enemy->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-body-enemy.obj");
        meshes[tank_body_enemy->GetMeshID()] = tank_body_enemy;

        // tracks
        Mesh* tank_tracks_enemy = new Mesh("tank_tracks_enemy");
        tank_tracks_enemy->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-tracks-enemy.obj");
        meshes[tank_tracks_enemy->GetMeshID()] = tank_tracks_enemy;

        // top big part
        Mesh* tank_top_big_enemy = new Mesh("tank_top_big_enemy");
        tank_top_big_enemy->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-top-bigPart-enemy.obj");
        meshes[tank_top_big_enemy->GetMeshID()] = tank_top_big_enemy;

        // top small part
        Mesh* tank_top_small_enemy = new Mesh("tank_top_small_enemy");
        tank_top_small_enemy->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "tank-top-smallPart-enemy.obj");
        meshes[tank_top_small_enemy->GetMeshID()] = tank_top_small_enemy;
    }

    {
        // projectile
        Mesh* projectile = new Mesh("projectile");
        projectile->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank"), "projectile.obj");
        meshes[projectile->GetMeshID()] = projectile;
    }

    {
        // Create a shader program for drawing face polygon with the color of the normal
        
        Shader* shader = new Shader("LabShader");
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema2", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema2", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
        shader->CreateAndLink();
        shaders[shader->GetName()] = shader;
    }

    // create enemies pozitione
    bool ok = false;
    float randomX, randomZ;
    while (ok == false) {
        randomX = generateRandomNumber();
        randomZ = generateRandomNumber();
        
        ok = canPlaceObject(randomX, randomZ);
    }
    enemies.push_back({ glm::vec3(randomX, 0.59, randomZ), glm::vec3(randomX, 0.59, randomZ), 0.04f, 0.02f, 0, 0 , -90.0f, true, false, MovementState::GoingForward, durationPointsEnemies, durationPointsEnemies, 3 });

    ok = false;
    while (ok == false) {
        randomX = generateRandomNumber();
        randomZ = generateRandomNumber();

        ok = canPlaceObject(randomX, randomZ);
    }
    enemies.push_back({ glm::vec3(randomX, 0.59, randomZ), glm::vec3(randomX, 0.59, randomZ), 0.04f, 0.02f, 0, 0 , -90.0f, true, false, MovementState::GoingForward, durationPointsEnemies, durationPointsEnemies, 3 });
    
    ok = false;
    while (ok == false) {
        randomX = generateRandomNumber();
        randomZ = generateRandomNumber();

        ok = canPlaceObject(randomX, randomZ);
    }
    enemies.push_back({ glm::vec3(randomX, 0.59, randomZ), glm::vec3(randomX, 0.59, randomZ), 0.04f, 0.02f, 0, 0 , 90.0f, false, true, MovementState::GoingForward, durationPointsEnemies, durationPointsEnemies, 3 });
    
    ok = false;
    while (ok == false) {
        randomX = generateRandomNumber();
        randomZ = generateRandomNumber();

        ok = canPlaceObject(randomX, randomZ);
    }
    enemies.push_back({ glm::vec3(randomX, 0.59, randomZ), glm::vec3(randomX, 0.59, randomZ), 0.04f, 0.02f, 0, 0 , 90.0f, false, true, MovementState::GoingForward, durationPointsEnemies, durationPointsEnemies, 3 });
    
    ok = false;
    while (ok == false) {
        randomX = generateRandomNumber();
        randomZ = generateRandomNumber();

        ok = canPlaceObject(randomX, randomZ);
    }
    enemies.push_back({ glm::vec3(randomX, 0.59, randomZ), glm::vec3(randomX, 0.59, randomZ), 0.04f, 0.02f, 0, 0 , -90.0f, true, false, MovementState::GoingForward, durationPointsEnemies, durationPointsEnemies, 3 });
    
    // Sets the resolution of the small viewport
    glm::ivec2 resolution = window->GetResolution();
    miniViewportArea = ViewportArea(50, 50, resolution.x / 5.f, resolution.y / 5.f);

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank", "14077_WWII_Tank_Germany_Panzer_III_hull_enemy.jpg").c_str(), GL_REPEAT);
        mapTextures["texture_base_enemy"] = texture;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank", "14077_WWII_Tank_Germany_Panzer_III_tracks_enemy.jpg").c_str(), GL_REPEAT);
        mapTextures["texture_tracks_enemy"] = texture;
    }

    {
        Texture2D* texture = new Texture2D();
        texture->Load2D(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "tank", "14077_WWII_Tank_Germany_Panzer_III_turret_enemy.jpg").c_str(), GL_REPEAT);
        mapTextures["texture_top_big_enemy"] = texture;
    }
}


void Tema2::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}


void Tema2::Update(float deltaTimeSeconds)
{ 
    if (gameOver == false) {

        glm::ivec2 resolution = window->GetResolution();

        glViewport(0, 0, resolution.x, resolution.y);

        RenderScene(deltaTimeSeconds);

        glClear(GL_DEPTH_BUFFER_BIT);

        miniViewportArea = ViewportArea(50, 50, resolution.x / 5.f, resolution.y / 5.f);

        glViewport(miniViewportArea.x, miniViewportArea.y, miniViewportArea.width, miniViewportArea.height);

        RenderScene(deltaTimeSeconds);

        if (gameOver && showedScore == false) {
            showedScore = true;
            cout << "You have made " << hits << " hits!" << endl;
            cout << "Destroyed " << score << " tanks!" << endl;
            cout << "And you have " << 1000 * score + 150 * hits << " points:)))" << endl;
        }
    }
}

void Tema2::RenderScene(float deltaTimeSeconds)
{
    {
        // floor randering
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.01, 0));
        RenderMesh(meshes["floor"], shaders["VertexNormal"], modelMatrix);
    }
    {
        // buildings
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[0].X, 0, limits[0].Z));
        RenderMesh(meshes["build1"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[1].X, 0, limits[1].Z));
        RenderMesh(meshes["build2"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[2].X, 0, limits[2].Z));
        RenderMesh(meshes["build3"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[3].X, 0, limits[3].Z));
        RenderMesh(meshes["build4"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[4].X, 0, limits[4].Z));
        RenderMesh(meshes["build5"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[5].X, 0, limits[5].Z));
        RenderMesh(meshes["build6"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[6].X, 0, limits[6].Z));
        RenderMesh(meshes["build6"], shaders["VertexNormal"], modelMatrix);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(limits[7].X, 0, limits[7].Z));
        RenderMesh(meshes["build3"], shaders["VertexNormal"], modelMatrix);
    }
    {
        // wall randering
        // fata
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 2, -25));
        RenderMesh(meshes["wall"], shaders["VertexNormal"], modelMatrix);

        // spate
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 2, 25));
        RenderMesh(meshes["wall"], shaders["VertexNormal"], modelMatrix);

        // stanga
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(-25, 2, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(0, 1, 0));
        RenderMesh(meshes["wall"], shaders["VertexNormal"], modelMatrix);

        // dreapta
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(25, 2, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(0, 1, 0));
        RenderMesh(meshes["wall"], shaders["VertexNormal"], modelMatrix);
    }

    {
        // render tank - main
        glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), catPosition) *
            glm::rotate(glm::mat4(1.0f), rotate_delta * rotate_press_num * glm::radians(-45.0f), glm::vec3(0, 1, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(rotate), glm::vec3(0, 1, 0));

        RenderMesh(meshes["tank_base_main"], shaders["Simple"], modelMatrix);
        RenderMesh(meshes["tank_tracks_main"], shaders["Simple"], modelMatrix);
        RenderMesh(meshes["tank_top_big_main"], shaders["Simple"], modelMatrix);
        RenderMesh(meshes["tank_top_small_main"], shaders["Simple"], modelMatrix);

        // main projactile
        if (timerPointsProjectile > 0) {
            timerPointsProjectile -= deltaTimeSeconds;
        }
        else {
            newProjectile = true;
        }
        std::vector<int> eraseAttackProjectile;
        for (int i = 0; i < attackProjectile.size(); i++) {
            
            for (int j = 0; j < limits.size(); j++) {
                if ((abs(attackProjectile[i].posX - limits[j].maxX) <= limits[j].limX
                    || abs(attackProjectile[i].posX - limits[j].minX) <= limits[j].limX)
                    && (abs(attackProjectile[i].posZ - limits[j].maxZ) <= limits[j].limZ
                        || abs(attackProjectile[i].posZ - limits[j].minZ) <= limits[j].limZ)) {
                    attackProjectile[i].isMooving = false;
                }
            }

            if (abs(22.5 * (-1) - attackProjectile[i].posX) <= 0.6f || abs(22.5 - attackProjectile[i].posX) <= 0.6f
                 || abs(22.5 * (-1) - attackProjectile[i].posZ) <= 0.6f || abs(22.5 - attackProjectile[i].posZ) <= 0.6f) {

                attackProjectile[i].isMooving = false;
            }

            if (attackProjectile[i].isMooving) {
                float angle = attackProjectile[i].rotate_delta * attackProjectile[i].rotate_press_num * -45.0f;
            
                attackProjectile[i].posX += deltaTimeSeconds * speedProjectile * (sin(angle * M_PI / 180)) * (-1);
                attackProjectile[i].posZ += deltaTimeSeconds * speedProjectile * (cos(angle * M_PI / 180)) * (-1);
            }

            attackProjectile[i].timerPoints -= deltaTimeSeconds;

            if (attackProjectile[i].timerPoints <= 0) {
                eraseAttackProjectile.push_back({ i });
            }
            else {
                modelMatrix = glm::mat4(1);
                modelMatrix = glm::translate(modelMatrix, glm::vec3(attackProjectile[i].posX, 0.59f, attackProjectile[i].posZ))
                    * glm::rotate(modelMatrix, attackProjectile[i].rotate_delta * attackProjectile[i].rotate_press_num * glm::radians(-45.0f), glm::vec3(0, 1, 0));
                modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.0f), glm::vec3(0, 1, 0));
                RenderMesh(meshes["projectile"], shaders["Simple"], modelMatrix);
            }
        }

        // rander enemies tanks
        for (int i = 0; i < enemies.size(); i++) {

            glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), enemies[i].catPosition)
                * glm::rotate(glm::mat4(1.0f), enemies[i].rotate_delta * enemies[i].rotate_press_num * glm::radians(-45.0f), glm::vec3(0, 1, 0));
            modelMatrix = glm::rotate(modelMatrix, RADIANS(enemies[i].rotation), glm::vec3(0, 1, 0));

            RenderSimpleMesh(meshes["tank_base_enemy"], shaders["LabShader"], modelMatrix, mapTextures["texture_base_enemy"], enemies[i].hp);
            RenderSimpleMesh(meshes["tank_tracks_enemy"], shaders["LabShader"], modelMatrix, mapTextures["texture_tracks_enemy"], enemies[i].hp);
            RenderSimpleMesh(meshes["tank_top_big_enemy"], shaders["LabShader"], modelMatrix, mapTextures["texture_top_big_enemy"], enemies[i].hp);
            RenderSimpleMesh(meshes["tank_top_small_enemy"], shaders["LabShader"], modelMatrix, mapTextures["texture_top_big_enemy"], enemies[i].hp);

            // check projectile
            for (int j = 0; j < attackProjectile.size(); j++) {
                if (abs(enemies[i].catPosition.x - attackProjectile[j].posX) <= 0.5f && abs(enemies[i].catPosition.z - attackProjectile[j].posZ) <= 0.5f) {

                    if (enemies[i].hp == 1) {
                        score++;
                    }

                    hits++;
                    enemies[i].hp--;
                    enemies[i].catPosition.y -= 0.03;

                    eraseAttackProjectile.push_back({ j });
                }
            }

            // execute state
            enemies[i].oldCatPosition = enemies[i].catPosition;

            if (enemies[i].hp > 0) {
                ExecuteCurrentState(i);
            }
            

            // set border limits
            if (enemies[i].catPosition.x < minX || enemies[i].catPosition.x > maxX
                || enemies[i].catPosition.z < minZ || enemies[i].catPosition.z > maxZ) {
                enemies[i].catPosition = enemies[i].oldCatPosition;
                enemies[i].timerPoints = 0;
            }

            // set buildings limits
            for (int j = 0; j < limits.size(); j++) {
                if ((abs(enemies[i].catPosition.x - limits[j].maxX) <= limits[j].limX || abs(enemies[i].catPosition.x - limits[j].minX) <= limits[j].limX)
                    && (abs(enemies[i].catPosition.z - limits[j].maxZ) <= limits[j].limZ || abs(enemies[i].catPosition.z - limits[j].minZ) <= limits[j].limZ)) {
                    enemies[i].catPosition = enemies[i].oldCatPosition;
                    enemies[i].timerPoints = 0;
                    break;
                }
            }

            // enemies collision limits
            for (int j = 0; j < enemies.size(); j++) {
                if (i != j && abs(enemies[j].catPosition.x - enemies[i].catPosition.x) <= tankColisionX
                    && abs(enemies[j].catPosition.z - enemies[i].catPosition.z) <= tankColisionZ) {
                    enemies[i].catPosition = enemies[i].oldCatPosition;
                    enemies[i].timerPoints = 0;
                }
            }

            // colision with main tank
            if (abs(enemies[i].catPosition.x - catPosition.x) <= tankColisionX && abs(enemies[i].catPosition.z - catPosition.z) <= tankColisionZ) {
                enemies[i].catPosition = enemies[i].oldCatPosition;
                enemies[i].timerPoints = 0;
            }

            enemies[i].timerPoints -= deltaTimeSeconds;
            if (enemies[i].timerPoints <= 0) {
                // choose another state
                enemies[i].state = GetNextMovementState(enemies[i].state);

                enemies[i].timerPoints = enemies[i].durationPoints;
            }
        }

        // erase projectile
        for (int i = 0; i < eraseAttackProjectile.size(); i++) {
            attackProjectile.erase(attackProjectile.begin() + eraseAttackProjectile[i]);
        }
    }

    // timer for 1 minute
    timerPoints -= deltaTimeSeconds;
    if (timerPoints <= 0) {
        gameOver = true;
    }
}

void Tema2::FrameEnd()
{

}

void Tema2::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, Texture2D* texture1, int HP)
{
    if (!mesh || !shader || !shader->GetProgramID())
        return;

    // Render an object using the specified shader and the specified position
    glUseProgram(shader->program);

    int location_model1 = glGetUniformLocation(shader->GetProgramID(), "Model");
    glUniformMatrix4fv(location_model1, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    int location_model2 = glGetUniformLocation(shader->GetProgramID(), "View");

    int location_model3 = glGetUniformLocation(shader->GetProgramID(), "Projection");
    shader->Use();
    glUniformMatrix4fv(location_model2, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));

    double time = Engine::GetElapsedTime();
    int location_model5 = glGetUniformLocation(shader->GetProgramID(), "HP");

    glUniform1f(location_model5, HP);

    glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
    glUniformMatrix4fv(location_model3, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

    glActiveTexture(GL_TEXTURE0);

    glBindTexture(GL_TEXTURE_2D, texture1->GetTextureID());

    glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);

    // Draw the object
    glBindVertexArray(mesh->GetBuffers()->m_VAO);
    glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_INT, 0);
}

void Tema2::RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix)
{
    if (!mesh || !shader || !shader->program)
        return;

    // Render an object using the specified shader and the specified position
    shader->Use();
    glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
    glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
    glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    mesh->Render();
}

void Tema2::OnInputUpdate(float deltaTime, int mods)
{
    
    catAngle = rotate_delta * rotate_press_num * -45.0f;
    glm::vec3 displacement = translate_delta * glm::vec3(sin(catAngle * M_PI / 180), 0, cos(catAngle * M_PI / 180));

    glm::vec3 oldCatPosition = catPosition;

    if (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)) {

        if (window->KeyHold(GLFW_KEY_S)) {
            catPosition += displacement;
        }

        if (window->KeyHold(GLFW_KEY_W)) {
            catPosition -= displacement;
        }

        if (window->KeyHold(GLFW_KEY_D)) {
            rotate_press_num++;
        }

        if (window->KeyHold(GLFW_KEY_A)) {
            rotate_press_num--;
        }
        bool ok = true;

        // set border limits - dorder
        if (catPosition.x < minX || catPosition.x > maxX
                || catPosition.z < minZ || catPosition.z > maxZ) {
            catPosition = oldCatPosition;
            ok = false;
        }
        else {
            // set limits for buildings
            for (int i = 0; i < limits.size(); i++) {
                if (( abs (catPosition.x - limits[i].maxX) <= limits[i].limX || abs(catPosition.x - limits[i].minX) <= limits[i].limX)
                            && ( abs(catPosition.z - limits[i].maxZ) <= limits[i].limZ || abs(catPosition.z - limits[i].minZ) <= limits[i].limZ)) {
                    catPosition = oldCatPosition;
                    ok = false;
                    break;
                }
            }

            // set limits for enemies
            for (int i = 0; i < enemies.size(); i++) {
                if (abs(enemies[i].catPosition.x - catPosition.x) <= tankColisionX && abs(enemies[i].catPosition.z - catPosition.z) <= tankColisionZ) {
                    catPosition = oldCatPosition;
                    ok = false;
                    break;
                }
            }
        }

        if ( ok ) {
            // camera movement with the tank
            if (da) {

                camera->distanceToTarget = oldCamera->distanceToTarget;
                camera->position = oldCamera->position;
                camera->forward = oldCamera->forward;
                camera->right = oldCamera->right;
                camera->up = oldCamera->up;

                da = false;
            }

            if (window->KeyHold(GLFW_KEY_S)) {
                camera->MoveForward(translate_delta * (-1));
            }
            if (window->KeyHold(GLFW_KEY_W)) {
                camera->MoveForward(translate_delta);
            }
            
        }
        if (window->KeyHold(GLFW_KEY_D)) {
            camera->RotateThirdPerson_OY(rotate_delta * RADIANS(-45.0f));
        }
        if (window->KeyHold(GLFW_KEY_A)) {
            camera->RotateThirdPerson_OY(rotate_delta * RADIANS(-45.0f) * (-1));
        }
    }
    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float cameraSpeed = 4.0f;
    }

    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        if (!da) {
            oldCamera->distanceToTarget = camera->distanceToTarget;
            oldCamera->position = camera->position;
            oldCamera->forward = camera->forward;
            oldCamera->right = camera->right;
            oldCamera->up = camera->up;

            da = true;
        }   
        float cameraSpeed = 2.0f;
        if (window->KeyHold(GLFW_KEY_W)) {
            camera->RotateFirstPerson_OX(rotate_delta);
        }
        if (window->KeyHold(GLFW_KEY_A)) {
            camera->RotateThirdPerson_OY(rotate_delta);
        }
        if (window->KeyHold(GLFW_KEY_S)) {
            camera->RotateFirstPerson_OX(rotate_delta * (-1));
        }
        if (window->KeyHold(GLFW_KEY_D)) {
            camera->RotateThirdPerson_OY(rotate_delta * (-1));
        }
    }

}


void Tema2::OnKeyPress(int key, int mods)
{

}


void Tema2::OnKeyRelease(int key, int mods)
{

}


void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    if (window->MouseHold(GLFW_MOUSE_BUTTON_LEFT)) {
        if (newProjectile) {

            glm::vec3 directions = glm::vec3(sin(catAngle * M_PI / 180), 0, cos(catAngle * M_PI / 180));
            float angleX = (directions.x < 0) ? -1 : 1;
            float angleZ = (directions.z < 0) ? -1 : 1;

            attackProjectile.push_back({ catPosition.x, catPosition.z, angleX, angleZ, true, 5.0f, 5.0f, rotate_delta, rotate_press_num});

            timerPointsProjectile = durationPointsProjectile;
            newProjectile = false;
        }
        
    }

    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float sensivityOX = 0.001f;
        float sensivityOY = 0.001f;

        if (!da) {

            oldCamera->distanceToTarget = camera->distanceToTarget;
            oldCamera->position = camera->position;
            oldCamera->forward = camera->forward;
            oldCamera->right = camera->right;
            oldCamera->up = camera->up;

            da = true;
        }

        if (window->GetSpecialKeyState() == 0) {
            renderCameraTarget = false;

            camera->RotateFirstPerson_OX(-sensivityOX * deltaY);
            camera->RotateFirstPerson_OY(-sensivityOY * deltaX);

        }

        if (window->GetSpecialKeyState() & GLFW_MOD_CONTROL) {
            renderCameraTarget = true;

            camera->RotateFirstPerson_OX(-sensivityOX * deltaY);
            camera->RotateFirstPerson_OY(-sensivityOY * deltaX);
        }
    }
}

void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{

}


void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{

}


void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema2::OnWindowResize(int width, int height)
{
}

void Tema2::ExecuteCurrentState(int i)
{
    float catAngle = enemies[i].rotate_delta * enemies[i].rotate_press_num * -45.0f;
    glm::vec3 displacement = enemies[i].translate_delta * glm::vec3(sin(catAngle * M_PI / 180), 0, cos(catAngle * M_PI / 180));

    if (enemies[i].W == true) {
        // S
        if (enemies[i].state == MovementState::GoingBackward) {
            enemies[i].catPosition += displacement;
        }

        // W
        if (enemies[i].state == MovementState::GoingForward) {
            enemies[i].catPosition -= displacement;
        }

        // D
        if (enemies[i].state == MovementState::InPlaceRotationRight) {
            enemies[i].rotate_press_num++;
        }

        // A
        if (enemies[i].state == MovementState::InPlaceRotationLeft) {
            enemies[i].rotate_press_num--;
        }
    }
    else if (enemies[i].S == true) {
        // S
        if (enemies[i].state == MovementState::GoingBackward) {
            enemies[i].catPosition -= displacement;
        }

        // W
        if (enemies[i].state == MovementState::GoingForward) {
            enemies[i].catPosition += displacement;
        }

        // D
        if (enemies[i].state == MovementState::InPlaceRotationRight) {
            enemies[i].rotate_press_num--;
        }

        // A
        if (enemies[i].state == MovementState::InPlaceRotationLeft) {
            enemies[i].rotate_press_num++;
        }
    }
}