﻿#include "lab_m1/Tema1/Tema1.h"

#include <vector>
#include <iostream>
#include <GLFW/glfw3.h>
#include <random>

#include "lab_m1/Tema1/transform2D_T1.h"
#include "lab_m1/Tema1/object2D_T1.h"

using namespace std;
using namespace m1;

glm::vec3 yellow(1.0f, 1.0f, 0.4f);
glm::vec3 corai(1.0f, 0.5f, 0.31f);
glm::vec3 purple(0.4f, 0.0f, 0.8f);
glm::vec3 blue(0.2f, 0.2f, 1.0f);

glm::vec3 yellowLight(1.4f, 1.4f, 0.8f);
glm::vec3 coraiLight(1.2f, 0.7f, 0.51f);
glm::vec3 purpleLight(0.9f, 0.7f, 1.0f);
glm::vec3 blueLight(0.74f, 0.84f, 0.84f);

glm::vec3 red(0.8f, 0, 0);
glm::vec3 pink(0.8f, 0.0f, 0.8f);
glm::vec3 grey(0.5f, 0.5f, 0.5f);
glm::vec3 white(1.0f, 1.0f, 1.0f);
glm::vec3 green(0.0f, 0.6f, 0.0f);

Tema1::Tema1()
{
}


Tema1::~Tema1()
{
}

float getRandomOption(const std::vector<float>& options) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, options.size() - 1);

    return options[dist(gen)];
}

int getRandomNumber(int minValue, int maxValue) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(minValue, maxValue);

    return dist(gen);
}

void Tema1::Init()
{
    glm::ivec2 resolution = window->GetResolution();
    auto camera = GetSceneCamera();
    camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
    camera->SetPosition(glm::vec3(0, 0, 100));
    camera->SetRotation(glm::vec3(0, 0, 0));
    camera->Update();
    GetCameraInput()->SetActive(false);

    timerEnemy = durationEnemy;
    timerPoints = durationPoints;

    glm::vec3 corner1 = glm::vec3(0, 0, 0);
    Mesh* weapon_place = object2D_T1::CreateSquare("weapon_place", corner1, squareSide_weapon_place, white);
    AddMeshToList(weapon_place);

    Mesh* weapon_place_unavailable = object2D_T1::CreateSquare("weapon_place_unavailable", corner1, squareSide_weapon_place, red);
    AddMeshToList(weapon_place_unavailable);

    Mesh* rectangle = object2D_T1::CreateRectangle("rectangle", corner1, sizeRectangle_length, sizeRectangle_height, red, true);
    AddMeshToList(rectangle);

    Mesh* pozitie_attack = object2D_T1::CreateSquare("pozitie_attack", corner1, squareSide_weapon_place, green, true);
    AddMeshToList(pozitie_attack);

    Mesh* weapon_yellow = object2D_T1::CreateWeapon("weapon_yellow", corner1, weaponSize, yellow, weaponZ);
    AddMeshToList(weapon_yellow);

    Mesh* weapon_corai = object2D_T1::CreateWeapon("weapon_corai", corner1, weaponSize, corai, weaponZ);
    AddMeshToList(weapon_corai);

    Mesh* weapon_purple = object2D_T1::CreateWeapon("weapon_purple", corner1, weaponSize, purple, weaponZ);
    AddMeshToList(weapon_purple);

    Mesh* weapon_blue = object2D_T1::CreateWeapon("weapon_blue", corner1, weaponSize, blue, weaponZ);
    AddMeshToList(weapon_blue);

    Mesh* star_points = object2D_T1::CreateStar("star_points", corner1, starPointsSize, pink, 1);
    AddMeshToList(star_points);

    Mesh* stars = object2D_T1::CreateStar("stars", corner1, constStarSize, grey, 0);
    AddMeshToList(stars);

    Mesh* yellow_stars = object2D_T1::CreateStar("yellow_stars", corner1, shootingStarSize, yellow, shootingStars_z);
    AddMeshToList(yellow_stars);

    Mesh* corai_stars = object2D_T1::CreateStar("corai_stars", corner1, shootingStarSize, corai, shootingStars_z);
    AddMeshToList(corai_stars);

    Mesh* purple_stars = object2D_T1::CreateStar("purple_stars", corner1, shootingStarSize, purple, shootingStars_z);
    AddMeshToList(purple_stars);

    Mesh* blue_stars = object2D_T1::CreateStar("blue_stars", corner1, shootingStarSize, blue, shootingStars_z);
    AddMeshToList(blue_stars);

    Mesh* life = object2D_T1::CreateLife("life", corner1, lifeSize, red);
    AddMeshToList(life);

    // enemy
    Mesh* enemy_yellow1 = object2D_T1::CreateEnemy("enemy_yellow1", corner1, enemyRadius, yellow, coraiLight);
    AddMeshToList(enemy_yellow1);
    defaultColorEnemies.push_back({ "enemy_yellow1" , yellow });

    Mesh* enemy_yellow2 = object2D_T1::CreateEnemy("enemy_yellow2", corner1, enemyRadius, yellow, purpleLight);
    AddMeshToList(enemy_yellow2);
    defaultColorEnemies.push_back({ "enemy_yellow2" , yellow });

    Mesh* enemy_yellow3 = object2D_T1::CreateEnemy("enemy_yellow3", corner1, enemyRadius, yellow, blueLight);
    AddMeshToList(enemy_yellow3);
    defaultColorEnemies.push_back({ "enemy_yellow3" , yellow });

    Mesh* enemy_corai1 = object2D_T1::CreateEnemy("enemy_corai1", corner1, enemyRadius, corai, yellowLight);
    AddMeshToList(enemy_corai1);
    defaultColorEnemies.push_back({ "enemy_corai1" , corai });

    Mesh* enemy_corai2 = object2D_T1::CreateEnemy("enemy_corai2", corner1, enemyRadius, corai, purpleLight);
    AddMeshToList(enemy_corai2);
    defaultColorEnemies.push_back({ "enemy_corai2" , corai });

    Mesh* enemy_corai3 = object2D_T1::CreateEnemy("enemy_corai3", corner1, enemyRadius, corai, blueLight);
    AddMeshToList(enemy_corai3);
    defaultColorEnemies.push_back({ "enemy_corai3" , corai });

    Mesh* enemy_purple1 = object2D_T1::CreateEnemy("enemy_purple1", corner1, enemyRadius, purple, yellowLight);
    AddMeshToList(enemy_purple1);
    defaultColorEnemies.push_back({ "enemy_purple1" , purple });

    Mesh* enemy_purple2 = object2D_T1::CreateEnemy("enemy_purple2", corner1, enemyRadius, purple, coraiLight);
    AddMeshToList(enemy_purple2);
    defaultColorEnemies.push_back({ "enemy_purple2" , purple });

    Mesh* enemy_purple3 = object2D_T1::CreateEnemy("enemy_purple3", corner1, enemyRadius, purple, blueLight);
    AddMeshToList(enemy_purple3);
    defaultColorEnemies.push_back({ "enemy_purple3" , purple });

    Mesh* enemy_blue1 = object2D_T1::CreateEnemy("enemy_blue1", corner1, enemyRadius, blue, yellowLight);
    AddMeshToList(enemy_blue1);
    defaultColorEnemies.push_back({ "enemy_blue1" , blue });

    Mesh* enemy_blue2 = object2D_T1::CreateEnemy("enemy_blue2", corner1, enemyRadius, blue, coraiLight);
    AddMeshToList(enemy_blue2);
    defaultColorEnemies.push_back({ "enemy_blue2" , blue });

    Mesh* enemy_blue3 = object2D_T1::CreateEnemy("enemy_blue3", corner1, enemyRadius, blue, purpleLight);
    AddMeshToList(enemy_blue3);
    defaultColorEnemies.push_back({ "enemy_blue3" , blue });


    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            AttackPlaceMatrix[i][j].taken = false;
        }
    }
}


void Tema1::FrameStart()
{
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    glViewport(0, 0, resolution.x, resolution.y);
}


void Tema1::Update(float deltaTimeSeconds)
{
    if (gameOver == false) {

        // casute arme

        // yellow
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(weaponPlaceX_1, weaponPlaceY);
        if (pointsNumber >= yellow_weapon) {
            RenderMesh2D(meshes["weapon_place"], shaders["VertexColor"], modelMatrix);
        }
        else {
            RenderMesh2D(meshes["weapon_place_unavailable"], shaders["VertexColor"], modelMatrix);
        }

        // corai
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(weaponPlaceX_2, weaponPlaceY);
        if (pointsNumber >= corai_weapon) {
            RenderMesh2D(meshes["weapon_place"], shaders["VertexColor"], modelMatrix);
        }
        else {
            RenderMesh2D(meshes["weapon_place_unavailable"], shaders["VertexColor"], modelMatrix);
        }

        // purple
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(weaponPlaceX_3, weaponPlaceY);
        if (pointsNumber >= purple_weapon) {
            RenderMesh2D(meshes["weapon_place"], shaders["VertexColor"], modelMatrix);
        }
        else {
            RenderMesh2D(meshes["weapon_place_unavailable"], shaders["VertexColor"], modelMatrix);
        }
        // blue
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(weaponPlaceX_4, weaponPlaceY);
        if (pointsNumber >= blue_weapon) {
            RenderMesh2D(meshes["weapon_place"], shaders["VertexColor"], modelMatrix);
        }
        else {
            RenderMesh2D(meshes["weapon_place_unavailable"], shaders["VertexColor"], modelMatrix);
        }

        // bara finala
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(20, first_rowY);
        RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

        // places for shooting
        for (int i = 0; i < 3; i++) {
            AttackPlaceMatrix[2][i].positionY = first_rowY;
            AttackPlaceMatrix[1][i].positionY = second_rowY;
            AttackPlaceMatrix[0][i].positionY = third_rowY;

            AttackPlaceMatrix[i][0].positionX = row_PlaceX_1;
            AttackPlaceMatrix[i][1].positionX = row_PlaceX_2;
            AttackPlaceMatrix[i][2].positionX = row_PlaceX_3;
        }
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                modelMatrix = glm::mat3(1);
                modelMatrix *= transform2D_T1::Translate(AttackPlaceMatrix[i][j].positionX, AttackPlaceMatrix[i][j].positionY);
                RenderMesh2D(meshes["pozitie_attack"], shaders["VertexColor"], modelMatrix);
            }
        }

        for (int w = 0; w < 3; w++) {
            for (int q = 0; q < 3; q++) {

                AttackPlaceMatrix[w][q].taken = false;

                for (int i = 0; i < weaponsInAction.size(); i++) {
                    if (weaponsInAction[i].positionX > AttackPlaceMatrix[w][q].positionX
                        && weaponsInAction[i].positionX < AttackPlaceMatrix[w][q].positionX + squareSide_weapon_place
                        && weaponsInAction[i].positionY > AttackPlaceMatrix[w][q].positionY
                        && weaponsInAction[i].positionY < AttackPlaceMatrix[w][q].positionY + squareSide_weapon_place
                        && weaponsInAction[i].erase == false) {

                        AttackPlaceMatrix[w][q].taken = true;
                    }
                }
            }
        }

        // weapon galben
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(yellow_weaponX, weaponY);
        RenderMesh2D(meshes["weapon_yellow"], shaders["VertexColor"], modelMatrix);

        // weapon corai
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(corai_weaponX, weaponY);
        RenderMesh2D(meshes["weapon_corai"], shaders["VertexColor"], modelMatrix);

        // weapon mov
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(purple_weaponX, weaponY);
        RenderMesh2D(meshes["weapon_purple"], shaders["VertexColor"], modelMatrix);

        // weapon albastru
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(blue_weaponX, weaponY);
        RenderMesh2D(meshes["weapon_blue"], shaders["VertexColor"], modelMatrix);


        // star points yellow
        modelMatrix = glm::mat3(1);
        modelMatrix *= transform2D_T1::Translate(starPointsYellowX_1, starPointsWeaponY);
        RenderMesh2D(meshes["stars"], shaders["VertexColor"], modelMatrix);

        // star points corai
        for (int i = 0; i < corai_weapon; i++) {
            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(starPointsCoraiX_1 + offset * i, starPointsWeaponY);
            RenderMesh2D(meshes["stars"], shaders["VertexColor"], modelMatrix);
        }

        // star points purple
        for (int i = 0; i < purple_weapon; i++) {
            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(starPointsPurpleX_1 + offset * i, starPointsWeaponY);
            RenderMesh2D(meshes["stars"], shaders["VertexColor"], modelMatrix);
        }

        // star points blue
        for (int i = 0; i < blue_weapon; i++) {
            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(starPointsBlueX_1 + offset * i, starPointsWeaponY);
            RenderMesh2D(meshes["stars"], shaders["VertexColor"], modelMatrix);
        }

        // life region
        for (int i = 0; i < livesLeft; i++) {
            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(heartX + offsetHeartsX * i, heartsY);
            RenderMesh2D(meshes["life"], shaders["VertexColor"], modelMatrix);
        }

        // captured stars
        for (int i = 0; i < pointsNumber; i++) {
            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(pointsX + offsetPoints_X * i, pointsY);
            RenderMesh2D(meshes["stars"], shaders["VertexColor"], modelMatrix);
        }

        // create enemies
        std::vector<int> eraseEnemyes;
        timerEnemy -= deltaTimeSeconds;
        if (timerEnemy <= 0)
        {
            int indexColor = getRandomNumber(0, enemyTypes - 1);

            float randomOptionY = getRandomOption(optionsPositionEnemyX);

            enemies.push_back({ startPositionX, randomOptionY, 1, 1, enemyHP_hearts , defaultColorEnemies[indexColor].color,
                defaultColorEnemies[indexColor].enemyName, false });

            timerEnemy = durationEnemy;
        }

        // generate star points
        timerPoints -= deltaTimeSeconds;
        if (timerPoints <= 0)
        {
            int numberStars = getRandomNumber(2, 4);

            for (int i = 0; i < numberStars; i++) {
                float randomPositionX = getRandomNumber(50, startPositionX - 50);
                float randomPositionY = getRandomNumber(20, third_rowY + 150);

                pointsToCollect.push_back({ randomPositionX, randomPositionY });
            }

            timerPoints = durationPoints;
        }

        // show star points to collect
        for (int i = 0; i < pointsToCollect.size(); i++) {

            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(pointsToCollect[i].positionX, pointsToCollect[i].positionY);
            RenderMesh2D(meshes["star_points"], shaders["VertexColor"], modelMatrix);
        }

        // show enemyes
        for (int i = 0; i < enemies.size(); i++) {

            if (enemies[i].positionX <= 25 && enemies[i].erase == false) {
                livesLeft--;
                enemies[i].erase = true;

                if (livesLeft == 0) {
                    gameOver = true;
                }
            }

            if (enemies[i].hpHears == 0) {
                enemies[i].erase = true;
            }

            if (enemies[i].erase == false) {
                modelMatrix = glm::mat3(1);

                enemies[i].positionX -= deltaTimeSeconds * 60;

                modelMatrix *= transform2D_T1::Translate(enemies[i].positionX + enemyRadius, enemies[i].positionY + enemyRadius);
                modelMatrix *= transform2D_T1::Rotate(-30);
                modelMatrix *= transform2D_T1::Translate(-enemyRadius, -enemyRadius);
                RenderMesh2D(meshes[enemies[i].name], shaders["VertexColor"], modelMatrix);
            }
            else {
                modelMatrix = glm::mat3(1);
                modelMatrix *= transform2D_T1::Translate(enemies[i].positionX + enemyRadius, enemies[i].positionY + enemyRadius);

                enemies[i].scaleX -= 0.9 * deltaTimeSeconds;
                enemies[i].scaleY -= 0.9 * deltaTimeSeconds;

                modelMatrix *= transform2D_T1::Scale(enemies[i].scaleX, enemies[i].scaleY);
                modelMatrix *= transform2D_T1::Rotate(-30);
                modelMatrix *= transform2D_T1::Translate(-enemyRadius, -enemyRadius);
                modelMatrix *= transform2D_T1::Translate(0, 0);
                RenderMesh2D(meshes[enemies[i].name], shaders["VertexColor"], modelMatrix);

                if (enemies[i].scaleX <= 0 && enemies[i].scaleY <= 0)
                    eraseEnemyes.push_back({ i });
            }
        }

        // drag and drop weapon
        if (isDragging) {
            modelMatrix = glm::mat3(1);
            modelMatrix *= transform2D_T1::Translate(weaponInMove.positionX, weaponInMove.positionY);
            RenderMesh2D(meshes[weaponInMove.nameWeapon], shaders["VertexColor"], modelMatrix);
        }

        // weapon in use
        std::vector<int> eraseWeapon;
        for (int i = 0; i < weaponsInAction.size(); i++) {

            for (int j = 0; j < enemies.size(); j++) {
                if (abs(enemies[j].positionX - weaponsInAction[i].positionX) <= enemyRadius + weaponSizeForColision 
                        && abs(enemies[j].positionY - weaponsInAction[i].positionY) <= 20) {

                    weaponsInAction[i].erase = true;

                    break;
                }
            }

            modelMatrix = glm::mat3(1);

            if (weaponsInAction[i].erase == false) {
                
                modelMatrix *= transform2D_T1::Translate(weaponsInAction[i].positionX, weaponsInAction[i].positionY);

                weaponsInAction[i].timer -= deltaTimeSeconds;

                if (weaponsInAction[i].timer <= 0) {
                    for (int j = 0; j < enemies.size(); j++) {
                        if (abs(enemies[j].positionY - weaponsInAction[i].positionY) <= 20 && enemies[j].color == weaponsInAction[i].color && enemies[j].erase == false) {

                            shootingStars.push_back({ weaponsInAction[i].positionX + starPointsSize, weaponsInAction[i].positionY + starPointsSize / 2 + 10, 0, 0,
                                    1, 1, weaponsInAction[i].color, false });

                            weaponsInAction[i].timer = weaponsInAction[i].duration;
                            break;
                        }
                    }
                }
            }
            else {
                weaponsInAction[i].scaleX -= 0.9 * deltaTimeSeconds;
                weaponsInAction[i].scaleY -= 0.9 * deltaTimeSeconds;

                modelMatrix = glm::mat3(1);
                modelMatrix *= transform2D_T1::Translate(weaponsInAction[i].positionX + weaponSize, weaponsInAction[i].positionY + weaponSize);
                modelMatrix *= transform2D_T1::Scale(weaponsInAction[i].scaleX, weaponsInAction[i].scaleY);
                modelMatrix *= transform2D_T1::Translate(-weaponSize, -weaponSize);

                if (weaponsInAction[i].scaleX <= 0 && weaponsInAction[i].scaleY <= 0) {

                    eraseWeapon.push_back({ i });
                }
            }

            RenderMesh2D(meshes[weaponsInAction[i].nameWeapon], shaders["VertexColor"], modelMatrix);
        }
        
        // erase weapon
        for (int i = 0; i < eraseWeapon.size(); i++) {
            weaponsInAction.erase(weaponsInAction.begin() + eraseWeapon[i]);
            


        }

        // star shooting
        std::vector<int> eraseShootingStars;

        for (int i = 0; i < shootingStars.size(); i++) {
            modelMatrix = glm::mat3(1);

            for (int k = 0; k < enemies.size(); k++) {
                if (shootingStars[i].color == enemies[k].color && abs(shootingStars[i].positionX - enemies[k].positionX) <= enemyRadius / 4
                    && abs(shootingStars[i].positionY - enemies[k].positionY) <= 55 && shootingStars[i].erase == false && enemies[k].erase == false) {

                    enemies[k].hpHears--;
                    shootingStars[i].erase = true;

                    break;
                }
            }

            if (shootingStars[i].erase == false) {

                shootingStars[i].positionX += deltaTimeSeconds * 350;
                shootingStars[i].radians += deltaTimeSeconds * 190;

                modelMatrix *= transform2D_T1::Translate(shootingStars[i].positionX, shootingStars[i].positionY);
                modelMatrix *= transform2D_T1::Rotate(RADIANS(shootingStars[i].radians));
                modelMatrix *= transform2D_T1::Translate(-shootingStarSize / 2, -shootingStarSize / 2);
            }
            else {
                shootingStars[i].scaleX -= 0.9 * deltaTimeSeconds;
                shootingStars[i].scaleY -= 0.9 * deltaTimeSeconds;

                modelMatrix *= transform2D_T1::Translate(shootingStars[i].positionX, shootingStars[i].positionY);
                modelMatrix *= transform2D_T1::Scale(shootingStars[i].scaleX, shootingStars[i].scaleY);
                modelMatrix *= transform2D_T1::Rotate(RADIANS(shootingStars[i].radians));
                modelMatrix *= transform2D_T1::Translate(-50,-50);

                if (shootingStars[i].scaleX <= 0 && shootingStars[i].scaleY <= 0)
                    eraseShootingStars.push_back({ i });
            }

            if (shootingStars[i].color == yellow) {
                RenderMesh2D(meshes["yellow_stars"], shaders["VertexColor"], modelMatrix);
            }
            else if (shootingStars[i].color == corai) {
                RenderMesh2D(meshes["corai_stars"], shaders["VertexColor"], modelMatrix);
            }
            else if (shootingStars[i].color == purple) {
                RenderMesh2D(meshes["purple_stars"], shaders["VertexColor"], modelMatrix);
            }
            else if (shootingStars[i].color == blue) {
                RenderMesh2D(meshes["blue_stars"], shaders["VertexColor"], modelMatrix);
            }
        }

        // erase shooting stars
        for (int i = 0; i < eraseShootingStars.size(); i++) {
            shootingStars.erase(shootingStars.begin() + eraseShootingStars[i]);
        }

        // erase enemies
        for (int i = 0; i < eraseEnemyes.size(); i++) {
            enemies.erase(enemies.begin() + eraseEnemyes[i]);
        }
    }
}


void Tema1::FrameEnd()
{
}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{
}

void Tema1::OnKeyPress(int key, int mods)
{
}


void Tema1::OnKeyRelease(int key, int mods)
{
}


void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    if (isDragging)
    {
        mouseY = window->GetResolution().y - mouseY;


        weaponInMove.positionX = mouseX - weaponSize / 2;
        weaponInMove.positionY = mouseY - weaponSize / 2;
    }
}


void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    mouseY = window->GetResolution().y - mouseY;
    if (IS_BIT_SET(button, GLFW_MOUSE_BUTTON_LEFT))
    {
        for (int i = 0; i < pointsToCollect.size(); i++) {
            if (mouseX >= pointsToCollect[i].positionX + 20 && mouseX <= pointsToCollect[i].positionX + starPointsSize - 20
                        && mouseY >= pointsToCollect[i].positionY + 20 && mouseY <= pointsToCollect[i].positionY + starPointsSize - 20) {
                pointsToCollect.erase(pointsToCollect.begin() + i);
                pointsNumber++;
            }
        }


        if (mouseY > weaponPlaceY && mouseY < weaponPlaceY + squareSide_weapon_place) {
            if (mouseX > weaponPlaceX_1 && mouseX < weaponPlaceX_1 + squareSide_weapon_place && pointsNumber >= yellow_weapon) {
                weaponInMove.positionX = mouseX - weaponSize / 2;
                weaponInMove.positionY = mouseY - weaponSize / 2;
                weaponInMove.nameWeapon = "weapon_yellow";
                weaponInMove.color = yellow;
                isDragging = true;
                weaponInMov = true;
            }
            else if (mouseX > weaponPlaceX_2 && mouseX < weaponPlaceX_2 + squareSide_weapon_place && pointsNumber >= corai_weapon) {
                weaponInMove.positionX = mouseX - weaponSize / 2;
                weaponInMove.positionY = mouseY - weaponSize / 2;
                weaponInMove.nameWeapon = "weapon_corai";
                weaponInMove.color = corai;
                isDragging = true;
                weaponInMov = true;
            }
            else if (mouseX > weaponPlaceX_3 && mouseX < weaponPlaceX_3 + squareSide_weapon_place && pointsNumber >= purple_weapon) {
                weaponInMove.positionX = mouseX + weaponSize / 2;
                weaponInMove.positionY = mouseY + weaponSize / 2;
                weaponInMove.nameWeapon = "weapon_purple";
                weaponInMove.color = purple;
                isDragging = true;
                weaponInMov = true;
            }
            else if (mouseX > weaponPlaceX_4 && mouseX < weaponPlaceX_4 + squareSide_weapon_place && pointsNumber >= blue_weapon) {
                weaponInMove.positionX = mouseX + weaponSize / 2;
                weaponInMove.positionY = mouseY + weaponSize / 2;
                weaponInMove.nameWeapon = "weapon_blue";
                weaponInMove.color = blue;
                isDragging = true;
                weaponInMov = true;
            }
        }
    }

    if (IS_BIT_SET(button, GLFW_MOUSE_BUTTON_RIGHT)) {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (mouseX > AttackPlaceMatrix[i][j].positionX 
                    && mouseX < AttackPlaceMatrix[i][j].positionX + squareSide_weapon_place
                    && mouseY > AttackPlaceMatrix[i][j].positionY 
                    && mouseY < AttackPlaceMatrix[i][j].positionY + squareSide_weapon_place) {

                    for (int k = 0; k < weaponsInAction.size(); k++) {
                        if (weaponsInAction[k].positionX > AttackPlaceMatrix[i][j].positionX 
                            && weaponsInAction[k].positionX < AttackPlaceMatrix[i][j].positionX + squareSide_weapon_place
                            && weaponsInAction[k].positionY > AttackPlaceMatrix[i][j].positionY 
                            && weaponsInAction[k].positionY < AttackPlaceMatrix[i][j].positionY + squareSide_weapon_place) {

                            weaponsInAction[k].erase = true;

                            AttackPlaceMatrix[i][j].taken = false;

                            break;
                        }
                    }
                }
            }
        }
    }
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    mouseY = window->GetResolution().y - mouseY;

    if (weaponInMov == true) {
        for (int i=0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (mouseX > AttackPlaceMatrix[i][j].positionX && mouseX < AttackPlaceMatrix[i][j].positionX + squareSide_weapon_place
                    && mouseY > AttackPlaceMatrix[i][j].positionY && mouseY < AttackPlaceMatrix[i][j].positionY + squareSide_weapon_place
                    && AttackPlaceMatrix[i][j].taken == false) {

                    if (weaponInMove.color == yellow) {
                        pointsNumber -= yellow_weapon;
                    }
                    else if (weaponInMove.color == corai) {
                        pointsNumber -= corai_weapon;
                    }
                    else if (weaponInMove.color == purple) {
                        pointsNumber -= purple_weapon;
                    }
                    else if (weaponInMove.color == blue) {
                        pointsNumber -= blue_weapon;
                    }

                    AttackPlaceMatrix[i][j].taken = true;

                    float posWeaponX = AttackPlaceMatrix[i][j].positionX + squareSide_weapon_place / 2 - 45;
                    float posWeaponY = AttackPlaceMatrix[i][j].positionY + 5;

                    weaponsInAction.push_back({ posWeaponX, posWeaponY, 1, 1, weaponInMove.nameWeapon, weaponInMove.color, durationShootingStars, 0 , false});
                }
            }
        }
        isDragging = false;
        weaponInMov = false;
    }
    
}


void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema1::OnWindowResize(int width, int height)
{
}
